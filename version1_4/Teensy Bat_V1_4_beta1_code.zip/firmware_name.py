from datetime import datetime
Import("env")
#get used build_flags
my_flags = env.ParseFlags(env['BUILD_FLAGS'])
defines = {k: v for (k, v) in my_flags.get("CPPDEFINES")}
#check if debugger was used
debugstr=""
if defines.get("DEBUGGER")=="1":
    debugstr="DEBUG"
   
#change the firmname    
env.Replace(PROGNAME="%s_" % env.GetProjectOption("current_version")+"for"+env.GetProjectOption("boardname")+"_"+str(datetime.now().strftime('%y%m%d_%H')+str(debugstr)))