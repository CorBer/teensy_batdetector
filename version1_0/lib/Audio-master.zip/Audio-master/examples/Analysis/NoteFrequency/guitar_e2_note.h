extern const unsigned int guitar_e2_note[52184];
